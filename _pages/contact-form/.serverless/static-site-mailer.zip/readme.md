#Building a serverless contact form for static website.

Following the Smashing Magazine [tutorial](https://www.smashingmagazine.com/2018/05/building-serverless-contact-form-static-website/) by Brian Holt 

Supplementary info from [serverless docs](https://serverless.com/framework/docs/providers/aws/guide/deploying/)